//
//  ViewController.swift
//  Light
//
//  Created by Jared Smith on 2/22/21.
//  Copyright © 2021 Jared Smith. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    var lightOn = true
    
    
    @IBAction func buttonPressed(_ sender: Any) {
        lightOn = !lightOn
        updateUI()
        
    }
    func updateUI() {
        view.backgroundColor = lightOn ? .white : .black
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        updateUI()
        // Do any additional setup after loading the view.
        
        
    }


}

